import java.io.IOException;
import java.net.ServerSocket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.*;
import java.util.concurrent.TimeoutException;
 
public class BlockchainClient {
 
    public static void main(String[] args) {
 
        if (args.length != 1) {
            return;
        }
        String configFileName = args[0];
 
        ServerInfoList pl = new ServerInfoList();
        pl.initialiseFromFile(configFileName);                     //to be tested
 
        Scanner sc = new Scanner(System.in);
        String message;
        while (sc.hasNextLine()) {
            // implement your code here
           message = sc.nextLine();
           if (message.startsWith("ls")) {
        	   System.out.print(pl.toString() + "\n");
           }
           
           else if (message.startsWith("ad")) {
        	   String[] tokens = message.split("\\|");
        	   
        	   int port = Integer.parseInt(tokens[2]);
        	   ServerInfo newServerInfo = new ServerInfo(tokens[1], port);
        	   boolean t = pl.addServerInfo(newServerInfo);
        	   if( t ) {
        		   System.out.print("Succeeded\n\n");
        	   }
        	   else {
        		   System.out.print("Failed\n\n");
        	   }
           }
           
           
           else if (message.startsWith("rm")) {
        	   String[] tokens = message.split("\\|");
        	   if(tokens.length != 2) {
        		   System.out.print("Failed\n\n");
        		   continue;
        	   }
        	   if (pl.removeServerInfo(Integer.parseInt(tokens[1]))) {
        		   System.out.print("Succeeded\n\n");
        	   } else {
        		   System.out.print("Failed\n\n");
        	   }
           }
           
           
           else if (message.startsWith("up")) {
        	   String[] tokens = message.split("\\|");
        	   if(tokens.length != 4) {
        		   System.out.print("Failed\n\n");
        		   continue;
        	   }
        	   if (pl.updateServerInfo(Integer.parseInt(tokens[1]), new ServerInfo(tokens[2],Integer.parseInt(tokens[3])))) {
        		   System.out.print("Succeeded\n\n");
        	   } else {
        		   System.out.print("Failed\n\n");
        	   }
           }
           
           
           else if(message.equals("cl")) {
        	   if (pl.clearServerInfo()) {
        		   System.out.print("Succeeded\n\n");
        	   } else {
        		   System.out.print("Failed\n\n");
        	   }
           }
           
           
           else if(message.startsWith("tx")) {
        	   new BlockchainClient().broadcast(pl, message);
           }
           
           
           else if(message.startsWith("pb")) {
        	   if (message.equals("pb")) {
        		   new BlockchainClient().broadcast(pl, message);
        	   }
        	   else {
        		   String tokens[] = message.split("\\|");
        		   ArrayList<Integer> serverIndices = new ArrayList<>();
        		   for(int i = 1; i < tokens.length; i ++) {
        			   serverIndices.add(Integer.parseInt(tokens[i]));
        		   }
        		   new BlockchainClient().multicast(pl, serverIndices, tokens[0]);
        	   }
           }
           
           
           else if(message.startsWith("sd")) {
        	   break;
           }
           
           
           else {
        	   System.out.print("Unknown Command\n\n");
           }
           
           
        }
        return;
    }
 
    public void unicast (int serverNumber, ServerInfo p, String message) {
        // implement your code here
		try {
			Thread bcr = new Thread(new BlockchainClientRunnable(serverNumber, p.getHost(), p.getPort(), message));
	    	bcr.start();
	    	bcr.join(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 
    }
 
    public void broadcast (ServerInfoList pl, String message) {
        // implement your code here
    	for(int i = 0; i < pl.getServerInfos().size(); i ++ ) {
    		new BlockchainClient().unicast(i, pl.getServerInfos().get(i), message);
    	}
    }
 
    public void multicast (ServerInfoList pl, ArrayList<Integer> serverIndices, String message) {
        // implement your code here
    	for(int i = 0; i < pl.getServerInfos().size(); i ++ ) {
    		for(int j = 0; j < serverIndices.size(); j ++) {
    			if( i == serverIndices.get(j)) {
    				new BlockchainClient().unicast(i, pl.getServerInfos().get(i), message);
    			}
    		}
    		
    	}
    }
 
    // implement any helper method here if you need any
}