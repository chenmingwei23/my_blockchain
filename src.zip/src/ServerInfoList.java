import java.io.*;
import java.util.*;
 
public class ServerInfoList {
 
    ArrayList<ServerInfo> serverInfos;
 
    public ServerInfoList() {
        serverInfos = new ArrayList<>();
    }
 
    public void initialiseFromFile(String filename) {
    	try{
    		BufferedReader inputReader = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
    		String inputStream = new String();
    		int serverNum = 0;
    		int help1 = 0;
    		while((inputStream = inputReader.readLine()) != null) {
    			if(inputStream.startsWith("servers.num")) {
    				String num = inputStream.substring(12);
    				if (inputStream.length() < 13) {
    					continue;
    				}
    				serverNum = Integer.parseInt(num);
    				if (serverNum <= 0) {
    					continue;
    				}
    				help1 = 1;
    				if (serverNum > serverInfos.size()) {
    					for(int i = serverInfos.size(); i < serverNum; i ++) {
    						serverInfos.add(i, new ServerInfo("", 65536));
    					}
    				}
    			}
    			
    			if(help1 == 0) {
    				serverInfos = null;
    				return;
    			}
    			
    			if(serverNum == 0) {
    				serverInfos = null;
    				return;
    			}
    			
    			if(inputStream.substring(8, 12).equals("host") || inputStream.substring(8, 12).equals("port")) {
    				int index = Integer.parseInt(inputStream.substring(6, 7));
    				if(index >= serverNum) {
    					continue;
    				}
    				if (inputStream.substring(8, 12).equals("host")) {
    					String host = inputStream.substring(13);
    					serverInfos.get(index).setHost(host);
    				}
    				if (inputStream.substring(8, 12).equals("port")) {
    					String portStr = inputStream.substring(13);
        				int port = Integer.parseInt(portStr);
        				serverInfos.get(index).setPort(port);
 
    				}
    			}
    		}
    		inputReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	for(int i = 0; i < serverInfos.size(); i ++) {
    		if(serverInfos.get(i).getHost().isEmpty() || serverInfos.get(i).getPort() > 65535 || serverInfos.get(i).getPort() < 1024) {
    			serverInfos.set(i, null);
    			continue;
    		}
    		String host = serverInfos.get(i).getHost();
    		if(host.equals("localhost")) {
    			continue;
    		}
    		String tokens[] = host.split("\\.");
    		if (tokens.length != 4) {
    			serverInfos.set(i, null);
    			continue;
    		}
    		for(int j = 0; j < 4; j ++) {
    			if(Integer.parseInt(tokens[j]) > 255 || Integer.parseInt(tokens[j]) < 0) {
    				serverInfos.set(i, null);
    				continue;
    			}
    		}
    	}  	
    }
 
    public ArrayList<ServerInfo> getServerInfos() {
        return serverInfos;
    }
 
    public void setServerInfos(ArrayList<ServerInfo> serverInfos) {
        this.serverInfos = serverInfos;
    }
 
    public boolean addServerInfo(ServerInfo newServerInfo) { 
        // implement your code here
    	if(newServerInfo.getPort() < 1024 || newServerInfo.getPort() > 65535) {
    		return false;
    	}
    	if(newServerInfo.getHost() == null || newServerInfo.getHost().equals("")){
    		return false;
    	}
    	serverInfos.add(newServerInfo);
    	return true;
    }
 
    public boolean updateServerInfo(int index, ServerInfo newServerInfo) { 
        // implement your code here
    	if(index >= serverInfos.size()) {
    		return false;
    	}
    	if(newServerInfo.getPort() < 1024 || newServerInfo.getPort() > 65535) {
    		return false;
    	}
    	serverInfos.set(index, newServerInfo);
    	return true;
    }
    
    public boolean removeServerInfo(int index) { 
        // implement your code here
    	if(index >= serverInfos.size() || index < 0) {
    		return false;
    	}
    	if (serverInfos.get(index) == null) {
    		return false;
    	}
    	serverInfos.set(index,null);
    	return true;
    }
 
    public boolean clearServerInfo() { 
        // implement your code here
    	int t = 1;
    	int i = 0;
    	while(i < serverInfos.size()) {
    		if(serverInfos.get(i) == null) {
    			serverInfos.remove(i);
    			t = t * 0;
    		}
    		else {
    			i ++;
    		}
    	}
    	if(t == 0) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
 
    public String toString() {
        String s = "";
        if(serverInfos == null) {
        	return null;
        }
        for (int i = 0; i < serverInfos.size(); i++) {
            if (serverInfos.get(i) != null) {
                s += "Server" + i + ": " + serverInfos.get(i).getHost() + " " + serverInfos.get(i).getPort() + "\n";
            }
        }
        return s;
    }
 
    // implement any helper method here if you need any
   /*public static void main(String a[]) {
    	String filename = a[0];
    	ServerInfoList t = new ServerInfoList();
    	t.initialiseFromFile(filename);
    	System.out.println(t.toString());
    }*/
}