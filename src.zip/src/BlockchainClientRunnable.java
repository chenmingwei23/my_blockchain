import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
 
public class BlockchainClientRunnable implements Runnable {
 
    private String reply;
    private int port;
    private String hostname;
    private String message;
    
    public BlockchainClientRunnable(int serverNumber, String serverName, int portNumber, String message) {
        this.reply = "Server" + serverNumber + ": " + serverName + " " + portNumber + "\n"; // header string
        this.port = portNumber;
        this.hostname = serverName;
        this.message = message;
    }
 
    public void run() {
        // implement your code here
    	try {
			Socket server = new Socket(hostname, port);
			BufferedReader serverStream = new BufferedReader(new InputStreamReader(server.getInputStream()));
			PrintWriter cstream = new PrintWriter(server.getOutputStream(), true);
			cstream.println(message);
			String serverString = serverStream.readLine();
			while (serverString != null && !serverString.equals("")) {
				reply = reply + serverString + "\n";
				serverString = serverStream.readLine();
			}
			cstream.println("cc");
			System.out.print(reply+"\n");
			cstream.flush();
			serverStream.close();
			server.close();
		} catch (BindException e) {
			System.out.print(reply);
			System.out.print("Cannot bind");
		} catch (ConnectException e) {
			System.out.print(reply);
			System.out.print("Server is not available\n\n");
		}  catch(UnknownHostException e) {
			System.out.print(reply);
			System.out.print("Wrong host name\n\n");
		} catch(IOException e) {
			//e.printStackTrace();
		} 
		
    }
 
    public String getReply() {
        return reply;
    }
 
    // implement any helper method here if you need any
}